<?php
include_once 'db.class.php';

Database::call(array(
            'driver' => 'mysql',
            'host' => 'localhost',
            'dbname' => 'work186',
            'login' => 'root',
            'pass' => 'root',
        ));
		
$id = 1;
$name = 'root';

//Database::query('SELECT * FROM users');
/*Database::select('SELECT * FROM users WHERE id = :id AND name = :name', array(
															'id' => $id,
															'name' => $name
															));
															*/
/*Database::insert('users', array(
								'name' => $name
								));
								*/