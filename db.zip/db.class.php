<?
/**
* Database Class
* 
* Small Database class for work
* 
* @author K.O.O
* @version 1.0
*/

class Database {
	/**
	 * Static instance of self
	 *
	 * @var object
	 */
	private static $instance;
	
	/* 
	* returns current object PDO or creates a new connection
	* 
	* @return object 
	*/	
	public static function call($connect = array()) {
		if(!isset(self::$instance))
		{
			try {
				self::$instance = new PDO("".$connect['driver'].":host=".$connect['host'].";dbname=".$connect['dbname'].";charset=utf8", $connect['login'], $connect['pass']);
				self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			} catch(PDOException $e)
			{
				echo 'Подключение не удалось: ' . $e->getMessage();
			}
		}
		return self::$instance;
	}
	
	/* 
	* query
	* @param string $query query
	*/ 	
	public function query($query) {
		$stmt = self::call()->prepare($query);
		$stmt->execute();
	}
	
    /**
     * select query
     * @param string $query query
     * @param array $values array of values
     * @return mixed
     */	
	public static function select($query, $values = array()) {
		$stmt = self::call()->prepare($query);
		foreach($values as $key=>$value) {
			$stmt->bindValue(":$key", $value);
		}
		$stmt->execute();
		return $stmt->fetchAll(PDO::FETCH_OBJ);
	}
	
	/**
	* insert query
	* @param string $table table name
	* @param array $values array of values
	*/ 
	public static function insert($table, $values = array())
	{
		$fields = implode( ', ', array_keys($values) );
		$bindvalues = ':' . implode( ', :', array_keys($values) );
			
		$stmt = self::call()->prepare("INSERT INTO $table (`$fields`) VALUES ($bindvalues)");
		foreach($values as $key => $value)
		{
			$stmt->bindValue( ":$key", $value );
		}
		$stmt->execute();    
	}
	
    /**
     * update query
     * @param string $table name of table
     * @param array $values array of values
     * @param string $where where
     */	
    public static function update($table, $values = array(), $where = null) {
        $fields = '';
        foreach($values as $key=> $value) {
            $fields .= "`$key`=:$key,";
        }
        $fields = rtrim($fields, ',');
		$where = !$where ? '' : 'WHERE '.$where;
		$stmt = self::call()->prepare("UPDATE $table SET $fields $where");
		
		foreach($values as $key => $value)
		{
			$stmt->bindValue(":$key", $value);
		}
		
		$stmt->execute();
    }
	
    /**
     * delete query
     * @param string $table name of table
     * @param string $where where insert
     */
	public static function delete($table, $where = null)
	{
		$where = !$where ? '' : 'WHERE '.$where;
		self::call()->exec("DELETE FROM $table $where");
    }
}